# Stage 2 - Instruction Filter

Some instructions are fake. Execute only the valid ones to compute the final result and unlock Stage 3.