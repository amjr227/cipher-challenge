
# Stage 2 - Instruction filter
instructions = [
    "LOAD R1, 24",    # valid
    "NOOP R1",        # fake
    "ADD R1, 5",      # valid
    "FLIP R9",        # fake
]

print("Analyze the valid instructions and calculate final R1.")
ans = input("Answer: ")
if ans.strip() == "correct_value":  # <-- fill in manually
    print("Correct. Use the key: stage3pass to unlock Stage 3.")
else:
    print("Incorrect.")
