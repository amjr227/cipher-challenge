
# Stage 1 - XOR Warmup
print("Solve this: 13 ^ 20 = ?")
ans = input("Answer: ")
if ans.strip() == "correct_value":  # <-- fill in manually
    print("Correct. Use the key: stage2pass to unlock Stage 2.")
else:
    print("Wrong answer.")
