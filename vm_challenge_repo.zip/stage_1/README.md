# Stage 1 - XOR Warmup

Solve the arithmetic puzzle to reveal the key for Stage 2.