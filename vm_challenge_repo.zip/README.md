# Multi-Stage VM Challenge

This is a puzzle for developers who enjoy decoding instructions, tracking fake ops, and breaking layered encryption.

## 🔐 Challenge Overview

- **Stage 1:** XOR arithmetic warmup
- **Stage 2:** Filter out fake VM instructions
- **Stage 3:** Break XOR encryption using deduction

Each stage gives you a key to proceed to the next. You'll need logic and patience to reach the end.

## 🧠 How to Participate

1. Start with `stage_1/challenge.py`
2. Solve it and note the unlock key for Stage 2
3. Repeat for each stage
4. Submit your final decoded word as proof you solved it

Good luck.

