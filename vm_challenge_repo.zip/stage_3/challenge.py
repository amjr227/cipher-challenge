
# Stage 3 - XOR Cipher
enc = [197, 199, 206, 207]  # Encrypted form of the hidden Arabic word
print("Decrypt this list using XOR with a secret seed.")
ans = input("Original word: ").strip()
if ans == "correct_word":  # <-- fill in manually
    print("Congratulations.")
else:
    print("Wrong.")
